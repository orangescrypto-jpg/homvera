import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  BadgeCheck, Camera, CheckCircle2, ChevronLeft, Clock, FileText,
  Shield, Upload, XCircle,
} from "lucide-react";
import { useRef, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const statusConfig = {
  pending: { label: "Under Review", icon: Clock, color: "text-yellow-600", bg: "bg-yellow-50", border: "border-yellow-200" },
  under_review: { label: "Under Review", icon: Clock, color: "text-blue-600", bg: "bg-blue-50", border: "border-blue-200" },
  approved: { label: "Approved", icon: CheckCircle2, color: "text-green-600", bg: "bg-green-50", border: "border-green-200" },
  rejected: { label: "Rejected", icon: XCircle, color: "text-red-600", bg: "bg-red-50", border: "border-red-200" },
};

export default function Verification() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const docInputRef = useRef<HTMLInputElement>(null);
  const selfieInputRef = useRef<HTMLInputElement>(null);

  const [documentType, setDocumentType] = useState<"nin" | "bvn" | "passport" | "drivers_license" | "utility_bill">("nin");
  const [docFile, setDocFile] = useState<File | null>(null);
  const [selfieFile, setSelfieFile] = useState<File | null>(null);
  const [docPreview, setDocPreview] = useState<string | null>(null);
  const [selfiePreview, setSelfiePreview] = useState<string | null>(null);

  const { data: verification, isLoading } = trpc.verification.myStatus.useQuery(undefined, { enabled: isAuthenticated });
  const utils = trpc.useUtils();

  const submitMutation = trpc.verification.submit.useMutation({
    onSuccess: () => {
      toast.success("Verification submitted! We'll review within 2-3 business days.");
      utils.verification.myStatus.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const handleFileSelect = (file: File, type: "doc" | "selfie") => {
    const reader = new FileReader();
    reader.onload = () => {
      if (type === "doc") {
        setDocFile(file);
        setDocPreview(reader.result as string);
      } else {
        setSelfieFile(file);
        setSelfiePreview(reader.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (!docFile) { toast.error("Please upload your document."); return; }

    const docReader = new FileReader();
    docReader.onload = async () => {
      const docBase64 = (docReader.result as string).split(",")[1];
      let selfieBase64: string | undefined;
      let selfieMime: string | undefined;

      if (selfieFile) {
        await new Promise<void>(resolve => {
          const selfieReader = new FileReader();
          selfieReader.onload = () => {
            selfieBase64 = (selfieReader.result as string).split(",")[1];
            selfieMime = selfieFile.type;
            resolve();
          };
          selfieReader.readAsDataURL(selfieFile);
        });
      }

      submitMutation.mutate({
        documentType,
        documentBase64: docBase64,
        documentMime: docFile.type,
        selfieBase64,
        selfieMime,
      });
    };
    docReader.readAsDataURL(docFile);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-30" />
          <h1 className="text-2xl font-serif font-bold mb-2">Sign In Required</h1>
          <Button asChild><a href={getLoginUrl()}>Sign In</a></Button>
        </div>
        <Footer />
      </div>
    );
  }

  if (user?.isVerified) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <BadgeCheck className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-2xl font-serif font-bold mb-2">Identity Verified!</h1>
          <p className="text-muted-foreground mb-6">Your identity has been verified. You have a verified badge on your profile.</p>
          <Button onClick={() => navigate("/dashboard")}>Go to Dashboard</Button>
        </div>
        <Footer />
      </div>
    );
  }

  const currentStatus = verification?.status;
  const statusInfo = currentStatus ? statusConfig[currentStatus as keyof typeof statusConfig] : null;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8 max-w-2xl">
        <button onClick={() => navigate("/dashboard")} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-6 transition-colors">
          <ChevronLeft className="w-4 h-4" /> Back to Dashboard
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
            <BadgeCheck className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-serif font-bold text-foreground">Identity Verification</h1>
            <p className="text-sm text-muted-foreground">Get verified to build trust and unlock all platform features</p>
          </div>
        </div>

        {/* Benefits */}
        <Card className="border-border mb-6">
          <CardContent className="p-5">
            <h3 className="font-semibold text-foreground mb-3">Benefits of Verification</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                "Verified badge on profile",
                "Higher listing visibility",
                "Access to premium features",
                "Increased buyer trust",
                "Faster escrow processing",
                "Priority support",
              ].map(benefit => (
                <div key={benefit} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                  {benefit}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Current Status */}
        {verification && statusInfo && (
          <Card className={`border ${statusInfo.border} ${statusInfo.bg} mb-6`}>
            <CardContent className="p-5 flex items-center gap-4">
              <statusInfo.icon className={`w-8 h-8 ${statusInfo.color} flex-shrink-0`} />
              <div>
                <p className="font-semibold text-foreground">Verification {statusInfo.label}</p>
                <p className="text-sm text-muted-foreground capitalize">Document: {verification.documentType.replace("_", " ")}</p>
                {verification.adminNotes && (
                  <p className="text-sm text-muted-foreground mt-1">Note: {verification.adminNotes}</p>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Submission Form */}
        {(!verification || verification.status === "rejected") && (
          <Card className="border-border">
            <CardContent className="p-6 space-y-5">
              <h3 className="font-semibold text-foreground">
                {verification?.status === "rejected" ? "Resubmit Verification" : "Submit Verification"}
              </h3>

              <div>
                <Label className="mb-2 block">Document Type</Label>
                <Select value={documentType} onValueChange={v => setDocumentType(v as typeof documentType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nin">National Identity Number (NIN)</SelectItem>
                    <SelectItem value="bvn">Bank Verification Number (BVN)</SelectItem>
                    <SelectItem value="passport">International Passport</SelectItem>
                    <SelectItem value="drivers_license">Driver's License</SelectItem>
                    <SelectItem value="utility_bill">Utility Bill (Proof of Address)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Document Upload */}
              <div>
                <Label className="mb-2 block">Upload Document *</Label>
                <div
                  onClick={() => docInputRef.current?.click()}
                  className="border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-primary transition-colors"
                >
                  {docPreview ? (
                    <div className="relative">
                      <img src={docPreview} alt="Document" className="max-h-40 mx-auto rounded-lg object-contain" />
                      <Badge className="mt-2 bg-green-100 text-green-800">Document uploaded</Badge>
                    </div>
                  ) : (
                    <>
                      <FileText className="w-10 h-10 mx-auto mb-2 text-muted-foreground opacity-50" />
                      <p className="text-sm text-muted-foreground">Click to upload your document</p>
                      <p className="text-xs text-muted-foreground mt-1">JPG, PNG, or PDF · Max 5MB</p>
                    </>
                  )}
                </div>
                <input
                  ref={docInputRef}
                  type="file"
                  accept="image/*,.pdf"
                  className="hidden"
                  onChange={e => e.target.files?.[0] && handleFileSelect(e.target.files[0], "doc")}
                />
              </div>

              {/* Selfie Upload */}
              <div>
                <Label className="mb-2 block">Selfie with Document (Optional but recommended)</Label>
                <div
                  onClick={() => selfieInputRef.current?.click()}
                  className="border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-primary transition-colors"
                >
                  {selfiePreview ? (
                    <div>
                      <img src={selfiePreview} alt="Selfie" className="max-h-40 mx-auto rounded-lg object-contain" />
                      <Badge className="mt-2 bg-green-100 text-green-800">Selfie uploaded</Badge>
                    </div>
                  ) : (
                    <>
                      <Camera className="w-10 h-10 mx-auto mb-2 text-muted-foreground opacity-50" />
                      <p className="text-sm text-muted-foreground">Take or upload a selfie holding your document</p>
                      <p className="text-xs text-muted-foreground mt-1">JPG or PNG · Max 5MB</p>
                    </>
                  )}
                </div>
                <input
                  ref={selfieInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={e => e.target.files?.[0] && handleFileSelect(e.target.files[0], "selfie")}
                />
              </div>

              <div className="flex items-start gap-2 text-xs text-muted-foreground bg-secondary/50 rounded-lg p-3">
                <Shield className="w-4 h-4 flex-shrink-0 mt-0.5 text-primary" />
                <span>Your documents are encrypted and stored securely. They are only used for identity verification and are never shared with third parties.</span>
              </div>

              <Button
                className="w-full gap-2"
                onClick={handleSubmit}
                disabled={!docFile || submitMutation.isPending}
              >
                <Upload className="w-4 h-4" />
                {submitMutation.isPending ? "Submitting..." : "Submit for Verification"}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
      <Footer />
    </div>
  );
}
