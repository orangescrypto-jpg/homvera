import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Components
import ChatbotWidget from "./components/ChatbotWidget";

// Public pages
import Home from "./pages/Home";
import Listings from "./pages/Listings";
import ListingDetail from "./pages/ListingDetail";
import NotFound from "./pages/NotFound";

// Legal pages
import TermsOfService from "./pages/legal/TermsOfService";
import PrivacyPolicy from "./pages/legal/PrivacyPolicy";
import EscrowAgreement from "./pages/legal/EscrowAgreement";
import CookiePolicy from "./pages/legal/CookiePolicy";

// Dashboard pages
import Dashboard from "./pages/dashboard/Dashboard";
import Profile from "./pages/dashboard/Profile";
import SavedListings from "./pages/dashboard/SavedListings";
import MyBookings from "./pages/dashboard/MyBookings";
import Notifications from "./pages/dashboard/Notifications";
import MyListings from "./pages/dashboard/MyListings";
import CreateListing from "./pages/dashboard/CreateListing";

// Chat
import Messages from "./pages/Messages";

// Escrow
import EscrowPage from "./pages/EscrowPage";

// Verification
import Verification from "./pages/Verification";

// Admin
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminListings from "./pages/admin/AdminListings";
import AdminEscrows from "./pages/admin/AdminEscrows";
import AdminVerifications from "./pages/admin/AdminVerifications";

function Router() {
  return (
    <Switch>
      {/* Public */}
      <Route path="/" component={Home} />
      <Route path="/listings" component={Listings} />
      <Route path="/listings/:id" component={ListingDetail} />

      {/* Legal */}
      <Route path="/terms" component={TermsOfService} />
      <Route path="/privacy" component={PrivacyPolicy} />
      <Route path="/escrow-agreement" component={EscrowAgreement} />
      <Route path="/cookies" component={CookiePolicy} />

      {/* Dashboard */}
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/dashboard/profile" component={Profile} />
      <Route path="/dashboard/saved" component={SavedListings} />
      <Route path="/dashboard/bookings" component={MyBookings} />
      <Route path="/dashboard/notifications" component={Notifications} />
      <Route path="/dashboard/listings" component={MyListings} />
      <Route path="/dashboard/listings/new" component={CreateListing} />

      {/* Chat */}
      <Route path="/messages" component={Messages} />
      <Route path="/messages/:conversationId" component={Messages} />

      {/* Escrow */}
      <Route path="/escrow/:bookingId" component={EscrowPage} />

      {/* Verification */}
      <Route path="/verify" component={Verification} />

      {/* Admin */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/listings" component={AdminListings} />
      <Route path="/admin/escrows" component={AdminEscrows} />
      <Route path="/admin/verifications" component={AdminVerifications} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
          <ChatbotWidget />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
