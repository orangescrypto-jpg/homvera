import { and, desc, eq, ilike, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  Booking,
  Conversation,
  InsertBooking,
  InsertEscrow,
  InsertListing,
  InsertMessage,
  InsertUser,
  InsertVerification,
  Listing,
  Message,
  bookings,
  chatbotSessions,
  conversations,
  escrows,
  listings,
  messages,
  notifications,
  reviews,
  savedListings,
  users,
  verifications,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function updateUserProfile(userId: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set(data).where(eq(users.id, userId));
}

export async function getAllUsers(limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt)).limit(limit).offset(offset);
}

// ─── Listings ─────────────────────────────────────────────────────────────────

export async function createListing(data: InsertListing) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(listings).values(data);
  return result;
}

export async function getListingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(listings).where(eq(listings.id, id)).limit(1);
  return result[0];
}

export async function getListingWithOwner(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({
      listing: listings,
      owner: {
        id: users.id,
        name: users.name,
        email: users.email,
        avatarUrl: users.avatarUrl,
        phone: users.phone,
        userRole: users.userRole,
        isVerified: users.isVerified,
      },
    })
    .from(listings)
    .leftJoin(users, eq(listings.ownerId, users.id))
    .where(eq(listings.id, id))
    .limit(1);
  return result[0];
}

export async function searchListings(params: {
  query?: string;
  category?: string;
  propertyType?: string;
  city?: string;
  state?: string;
  minPrice?: number;
  maxPrice?: number;
  status?: string;
  limit?: number;
  offset?: number;
  featured?: boolean;
}) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [];
  if (params.status) {
    conditions.push(eq(listings.status, params.status as Listing["status"]));
  } else {
    conditions.push(eq(listings.status, "active"));
  }
  if (params.query) {
    conditions.push(
      or(
        like(listings.title, `%${params.query}%`),
        like(listings.description, `%${params.query}%`),
        like(listings.city, `%${params.query}%`),
        like(listings.address, `%${params.query}%`)
      )
    );
  }
  if (params.category) conditions.push(eq(listings.category, params.category as Listing["category"]));
  if (params.propertyType) conditions.push(eq(listings.propertyType, params.propertyType as Listing["propertyType"]));
  if (params.city) conditions.push(like(listings.city, `%${params.city}%`));
  if (params.state) conditions.push(like(listings.state, `%${params.state}%`));
  if (params.featured) conditions.push(eq(listings.isFeatured, true));

  return db
    .select()
    .from(listings)
    .where(and(...conditions))
    .orderBy(desc(listings.isFeatured), desc(listings.createdAt))
    .limit(params.limit ?? 20)
    .offset(params.offset ?? 0);
}

export async function getFeaturedListings(limit = 6) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(listings)
    .where(and(eq(listings.isFeatured, true), eq(listings.status, "active")))
    .orderBy(desc(listings.createdAt))
    .limit(limit);
}

export async function getUserListings(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(listings).where(eq(listings.ownerId, userId)).orderBy(desc(listings.createdAt));
}

export async function updateListing(id: number, data: Partial<InsertListing>) {
  const db = await getDb();
  if (!db) return;
  await db.update(listings).set(data).where(eq(listings.id, id));
}

export async function deleteListing(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(listings).where(eq(listings.id, id));
}

export async function incrementListingViews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(listings).set({ viewCount: sql`${listings.viewCount} + 1` }).where(eq(listings.id, id));
}

export async function getAllListingsAdmin(limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(listings).orderBy(desc(listings.createdAt)).limit(limit).offset(offset);
}

// ─── Saved Listings ───────────────────────────────────────────────────────────

export async function saveListing(userId: number, listingId: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(savedListings).values({ userId, listingId }).onDuplicateKeyUpdate({ set: { userId } });
}

export async function unsaveListing(userId: number, listingId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(savedListings).where(and(eq(savedListings.userId, userId), eq(savedListings.listingId, listingId)));
}

export async function getUserSavedListings(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ listing: listings })
    .from(savedListings)
    .leftJoin(listings, eq(savedListings.listingId, listings.id))
    .where(eq(savedListings.userId, userId))
    .orderBy(desc(savedListings.createdAt));
}

export async function isListingSaved(userId: number, listingId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select()
    .from(savedListings)
    .where(and(eq(savedListings.userId, userId), eq(savedListings.listingId, listingId)))
    .limit(1);
  return result.length > 0;
}

// ─── Bookings ─────────────────────────────────────────────────────────────────

export async function createBooking(data: InsertBooking) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(bookings).values(data);
  return result;
}

export async function getBookingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
  return result[0];
}

export async function getUserBookings(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(bookings)
    .where(or(eq(bookings.buyerId, userId), eq(bookings.sellerId, userId)))
    .orderBy(desc(bookings.createdAt));
}

export async function updateBookingStatus(id: number, status: Booking["status"]) {
  const db = await getDb();
  if (!db) return;
  await db.update(bookings).set({ status }).where(eq(bookings.id, id));
}

// ─── Conversations & Messages ─────────────────────────────────────────────────

export async function getOrCreateConversation(participant1Id: number, participant2Id: number, listingId?: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");

  const existing = await db
    .select()
    .from(conversations)
    .where(
      or(
        and(eq(conversations.participant1Id, participant1Id), eq(conversations.participant2Id, participant2Id)),
        and(eq(conversations.participant1Id, participant2Id), eq(conversations.participant2Id, participant1Id))
      )
    )
    .limit(1);

  if (existing.length > 0) return existing[0];

  await db.insert(conversations).values({ participant1Id, participant2Id, listingId });
  const created = await db
    .select()
    .from(conversations)
    .where(
      and(eq(conversations.participant1Id, participant1Id), eq(conversations.participant2Id, participant2Id))
    )
    .limit(1);
  return created[0];
}

export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(conversations)
    .where(or(eq(conversations.participant1Id, userId), eq(conversations.participant2Id, userId)))
    .orderBy(desc(conversations.lastMessageAt));
}

export async function getConversationMessages(conversationId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
}

export async function sendMessage(data: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(messages).values(data);
  await db
    .update(conversations)
    .set({ lastMessageAt: new Date() })
    .where(eq(conversations.id, data.conversationId));
}

export async function markMessagesRead(conversationId: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(messages)
    .set({ isRead: true })
    .where(and(eq(messages.conversationId, conversationId), eq(messages.isRead, false)));
}

// ─── Escrow ───────────────────────────────────────────────────────────────────

export async function createEscrow(data: InsertEscrow) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(escrows).values(data);
  const result = await db
    .select()
    .from(escrows)
    .where(eq(escrows.bookingId, data.bookingId))
    .orderBy(desc(escrows.createdAt))
    .limit(1);
  return result[0];
}

export async function getEscrowById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(escrows).where(eq(escrows.id, id)).limit(1);
  return result[0];
}

export async function getEscrowByBookingId(bookingId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(escrows).where(eq(escrows.bookingId, bookingId)).limit(1);
  return result[0];
}

export async function updateEscrow(id: number, data: Partial<typeof escrows.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(escrows).set(data).where(eq(escrows.id, id));
}

export async function getUserEscrows(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(escrows)
    .where(or(eq(escrows.buyerId, userId), eq(escrows.sellerId, userId)))
    .orderBy(desc(escrows.createdAt));
}

export async function getAllEscrowsAdmin(limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(escrows).orderBy(desc(escrows.createdAt)).limit(limit).offset(offset);
}

// ─── Verification ─────────────────────────────────────────────────────────────

export async function createVerification(data: InsertVerification) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(verifications).values(data);
}

export async function getUserVerification(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(verifications)
    .where(eq(verifications.userId, userId))
    .orderBy(desc(verifications.createdAt))
    .limit(1);
  return result[0];
}

export async function updateVerification(id: number, data: Partial<typeof verifications.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  await db.update(verifications).set(data).where(eq(verifications.id, id));
}

export async function getPendingVerifications(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(verifications)
    .where(or(eq(verifications.status, "pending"), eq(verifications.status, "under_review")))
    .orderBy(desc(verifications.createdAt))
    .limit(limit);
}

// ─── Notifications ────────────────────────────────────────────────────────────

export async function createNotification(data: {
  userId: number;
  type: string;
  title: string;
  message: string;
  relatedId?: number;
  relatedType?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values(data);
}

export async function getUserNotifications(userId: number, limit = 30) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function markNotificationRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
}

// ─── Reviews ──────────────────────────────────────────────────────────────────

export async function getListingReviews(listingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ review: reviews, reviewer: { id: users.id, name: users.name, avatarUrl: users.avatarUrl } })
    .from(reviews)
    .leftJoin(users, eq(reviews.reviewerId, users.id))
    .where(eq(reviews.listingId, listingId))
    .orderBy(desc(reviews.createdAt));
}

export async function createReview(data: { listingId: number; reviewerId: number; rating: number; comment?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(reviews).values(data);
}

// ─── Chatbot Sessions ─────────────────────────────────────────────────────────

export async function getChatbotSession(sessionKey: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(chatbotSessions)
    .where(eq(chatbotSessions.sessionKey, sessionKey))
    .limit(1);
  return result[0];
}

export async function upsertChatbotSession(sessionKey: string, history: unknown[], userId?: number) {
  const db = await getDb();
  if (!db) return;
  const historyJson = JSON.stringify(history);
  await db
    .insert(chatbotSessions)
    .values({ sessionKey, history: historyJson, userId })
    .onDuplicateKeyUpdate({ set: { history: historyJson } });
}

// ─── Analytics ────────────────────────────────────────────────────────────────

export async function getAdminStats() {
  const db = await getDb();
  if (!db) return { users: 0, listings: 0, escrows: 0, pendingVerifications: 0 };

  const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
  const [listingCount] = await db.select({ count: sql<number>`count(*)` }).from(listings);
  const [escrowCount] = await db.select({ count: sql<number>`count(*)` }).from(escrows);
  const [verificationCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(verifications)
    .where(eq(verifications.status, "pending"));

  return {
    users: Number(userCount?.count ?? 0),
    listings: Number(listingCount?.count ?? 0),
    escrows: Number(escrowCount?.count ?? 0),
    pendingVerifications: Number(verificationCount?.count ?? 0),
  };
}
