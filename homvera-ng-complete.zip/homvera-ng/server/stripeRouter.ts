import { Router, Request, Response } from "express";
import Stripe from "stripe";
import { updateEscrow, getEscrowById, createNotification } from "./db";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? "", {
  apiVersion: "2026-04-22.dahlia",
});

export const stripeRouter = Router();

// ── Create Checkout Session for Escrow ────────────────────────────────────────
stripeRouter.post("/create-escrow-session", async (req: Request, res: Response) => {
  try {
    const { escrowId, amount, currency, listingTitle, buyerEmail, origin } = req.body as {
      escrowId: number;
      amount: number;
      currency: string;
      listingTitle: string;
      buyerEmail?: string;
      origin: string;
    };

    if (!escrowId || !amount || !origin) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: currency?.toLowerCase() ?? "usd",
            product_data: {
              name: `Escrow: ${listingTitle ?? "Property Transaction"}`,
              description: `Secure escrow payment for Homvera NG transaction #${escrowId}`,
            },
            unit_amount: Math.round(amount * 100), // Convert to cents
          },
          quantity: 1,
        },
      ],
      customer_email: buyerEmail,
      client_reference_id: String(escrowId),
      metadata: {
        escrow_id: String(escrowId),
        platform: "homvera_ng",
      },
      success_url: `${origin}/escrow/${req.body.bookingId}?payment=success`,
      cancel_url: `${origin}/escrow/${req.body.bookingId}?payment=cancelled`,
      allow_promotion_codes: true,
    });

    res.json({ url: session.url, sessionId: session.id });
  } catch (error) {
    console.error("[Stripe] Checkout session error:", error);
    res.status(500).json({ error: "Failed to create checkout session" });
  }
});

// ── Stripe Webhook ────────────────────────────────────────────────────────────
stripeRouter.post("/webhook", async (req: Request, res: Response) => {
  const sig = req.headers["stripe-signature"] as string;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret ?? "");
  } catch (err) {
    console.error("[Webhook] Signature verification failed:", err);
    res.status(400).send("Webhook signature verification failed");
    return;
  }

  // Handle test events
  if (event.id.startsWith("evt_test_")) {
    console.log("[Webhook] Test event detected, returning verification response");
    res.json({ verified: true });
    return;
  }

  console.log(`[Webhook] Event: ${event.type} | ID: ${event.id}`);

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const escrowId = session.metadata?.escrow_id;
        if (escrowId) {
          const escrow = await getEscrowById(parseInt(escrowId));
          if (escrow) {
            await updateEscrow(parseInt(escrowId), {
              status: "funded",
              stripePaymentIntentId: session.payment_intent as string,
              fundedAt: new Date(),
            });
            await createNotification({
              userId: escrow.sellerId,
              type: "escrow_funded",
              title: "Escrow Funded",
              message: "The buyer has funded the escrow. Proceed with delivery.",
            });
            await createNotification({
              userId: escrow.buyerId,
              type: "escrow_funded",
              title: "Payment Confirmed",
              message: "Your escrow payment has been confirmed. The seller has been notified.",
            });
          }
        }
        break;
      }

      case "payment_intent.payment_failed": {
        const intent = event.data.object as Stripe.PaymentIntent;
        console.log(`[Webhook] Payment failed: ${intent.id}`);
        break;
      }

      default:
        console.log(`[Webhook] Unhandled event type: ${event.type}`);
    }
  } catch (err) {
    console.error("[Webhook] Processing error:", err);
    res.status(500).json({ error: "Webhook processing failed" });
    return;
  }

  res.json({ received: true });
});
