import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import {
  createBooking,
  createEscrow,
  createListing,
  createNotification,
  createReview,
  createVerification,
  deleteListing,
  getAdminStats,
  getAllEscrowsAdmin,
  getAllListingsAdmin,
  getAllUsers,
  getBookingById,
  getChatbotSession,
  getConversationMessages,
  getEscrowByBookingId,
  getEscrowById,
  getFeaturedListings,
  getListingById,
  getListingReviews,
  getListingWithOwner,
  getOrCreateConversation,
  getPendingVerifications,
  getUserBookings,
  getUserConversations,
  getUserById,
  getUserEscrows,
  getUserListings,
  getUserNotifications,
  getUserSavedListings,
  getUserVerification,
  incrementListingViews,
  isListingSaved,
  markAllNotificationsRead,
  markMessagesRead,
  markNotificationRead,
  saveListing,
  searchListings,
  sendMessage,
  unsaveListing,
  updateBookingStatus,
  updateEscrow,
  updateListing,
  updateUserProfile,
  updateVerification,
  upsertChatbotSession,
} from "./db";

// ─── Admin guard ──────────────────────────────────────────────────────────────
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,

  // ── Auth ──────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    updateProfile: protectedProcedure
      .input(z.object({
        name: z.string().optional(),
        phone: z.string().optional(),
        bio: z.string().optional(),
        location: z.string().optional(),
        userRole: z.enum(["buyer", "seller", "agent", "admin"]).optional(),
        avatarUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateUserProfile(ctx.user.id, input);
        return { success: true };
      }),
    uploadAvatar: protectedProcedure
      .input(z.object({ base64: z.string(), mimeType: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.base64, "base64");
        const key = `avatars/${ctx.user.id}-${Date.now()}.jpg`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        await updateUserProfile(ctx.user.id, { avatarUrl: url });
        return { url };
      }),
  }),

  // ── Listings ──────────────────────────────────────────────────────────────
  listings: router({
    search: publicProcedure
      .input(z.object({
        query: z.string().optional(),
        category: z.string().optional(),
        propertyType: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        minPrice: z.number().optional(),
        maxPrice: z.number().optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      }))
      .query(async ({ input }) => {
        return searchListings(input);
      }),

    featured: publicProcedure.query(async () => getFeaturedListings(6)),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const listing = await getListingWithOwner(input.id);
        if (!listing) throw new TRPCError({ code: "NOT_FOUND" });
        await incrementListingViews(input.id);
        return listing;
      }),

    getReviews: publicProcedure
      .input(z.object({ listingId: z.number() }))
      .query(async ({ input }) => getListingReviews(input.listingId)),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(5),
        description: z.string().optional(),
        category: z.enum(["housing", "services"]),
        propertyType: z.enum(["apartment", "house", "land", "commercial", "shortlet", "cleaning", "repairs", "installation", "logistics", "other"]),
        price: z.string(),
        priceUnit: z.enum(["total", "per_month", "per_year", "per_day", "per_service"]).default("total"),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        latitude: z.string().optional(),
        longitude: z.string().optional(),
        bedrooms: z.number().optional(),
        bathrooms: z.number().optional(),
        area: z.string().optional(),
        images: z.array(z.string()).optional(),
        amenities: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await createListing({
          ...input,
          ownerId: ctx.user.id,
          images: input.images ? JSON.stringify(input.images) : undefined,
          amenities: input.amenities ? JSON.stringify(input.amenities) : undefined,
          status: "pending",
        });
        return { success: true };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        price: z.string().optional(),
        status: z.enum(["draft", "pending", "active", "rejected", "sold", "rented"]).optional(),
        images: z.array(z.string()).optional(),
        amenities: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const listing = await getListingById(input.id);
        if (!listing) throw new TRPCError({ code: "NOT_FOUND" });
        if (listing.ownerId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const { id, images, amenities, ...rest } = input;
        await updateListing(id, {
          ...rest,
          images: images ? JSON.stringify(images) : undefined,
          amenities: amenities ? JSON.stringify(amenities) : undefined,
        });
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const listing = await getListingById(input.id);
        if (!listing) throw new TRPCError({ code: "NOT_FOUND" });
        if (listing.ownerId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await deleteListing(input.id);
        return { success: true };
      }),

    myListings: protectedProcedure.query(async ({ ctx }) => getUserListings(ctx.user.id)),

    uploadImage: protectedProcedure
      .input(z.object({ base64: z.string(), mimeType: z.string(), filename: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.base64, "base64");
        const key = `listings/${ctx.user.id}/${Date.now()}-${input.filename}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        return { url };
      }),

    addReview: protectedProcedure
      .input(z.object({ listingId: z.number(), rating: z.number().min(1).max(5), comment: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        await createReview({ ...input, reviewerId: ctx.user.id });
        return { success: true };
      }),

    savedListings: protectedProcedure.query(async ({ ctx }) => getUserSavedListings(ctx.user.id)),

    save: protectedProcedure
      .input(z.object({ listingId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await saveListing(ctx.user.id, input.listingId);
        return { success: true };
      }),

    unsave: protectedProcedure
      .input(z.object({ listingId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await unsaveListing(ctx.user.id, input.listingId);
        return { success: true };
      }),

    isSaved: protectedProcedure
      .input(z.object({ listingId: z.number() }))
      .query(async ({ ctx, input }) => isListingSaved(ctx.user.id, input.listingId)),
  }),

  // ── Bookings ──────────────────────────────────────────────────────────────
  bookings: router({
    create: protectedProcedure
      .input(z.object({
        listingId: z.number(),
        sellerId: z.number(),
        message: z.string().optional(),
        scheduledAt: z.date().optional(),
        totalAmount: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await createBooking({ ...input, buyerId: ctx.user.id, status: "pending" });
        await createNotification({
          userId: input.sellerId,
          type: "booking_request",
          title: "New Booking Request",
          message: `You have a new booking request from ${ctx.user.name ?? "a buyer"}.`,
        });
        return { success: true };
      }),

    myBookings: protectedProcedure.query(async ({ ctx }) => getUserBookings(ctx.user.id)),

    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.enum(["pending", "confirmed", "completed", "cancelled", "disputed"]) }))
      .mutation(async ({ ctx, input }) => {
        const booking = await getBookingById(input.id);
        if (!booking) throw new TRPCError({ code: "NOT_FOUND" });
        if (booking.buyerId !== ctx.user.id && booking.sellerId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updateBookingStatus(input.id, input.status);
        return { success: true };
      }),
  }),

  // ── Messages ──────────────────────────────────────────────────────────────
  messages: router({
    getConversations: protectedProcedure.query(async ({ ctx }) => {
      const convs = await getUserConversations(ctx.user.id);
      const result = await Promise.all(
        convs.map(async (conv) => {
          const otherId = conv.participant1Id === ctx.user.id ? conv.participant2Id : conv.participant1Id;
          const other = await getUserById(otherId);
          const msgs = await getConversationMessages(conv.id, 1);
          return { ...conv, otherUser: other, lastMessage: msgs[0] };
        })
      );
      return result;
    }),

    getMessages: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ ctx, input }) => {
        await markMessagesRead(input.conversationId, ctx.user.id);
        const msgs = await getConversationMessages(input.conversationId, 50);
        return msgs.reverse();
      }),

    send: protectedProcedure
      .input(z.object({ conversationId: z.number(), content: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        await sendMessage({ ...input, senderId: ctx.user.id, messageType: "text" });
        return { success: true };
      }),

    startConversation: protectedProcedure
      .input(z.object({ recipientId: z.number(), listingId: z.number().optional() }))
      .mutation(async ({ ctx, input }) => {
        const conv = await getOrCreateConversation(ctx.user.id, input.recipientId, input.listingId);
        return conv;
      }),
  }),

  // ── Escrow ────────────────────────────────────────────────────────────────
  escrow: router({
    initiate: protectedProcedure
      .input(z.object({
        bookingId: z.number(),
        sellerId: z.number(),
        amount: z.string(),
        currency: z.string().default("USD"),
      }))
      .mutation(async ({ ctx, input }) => {
        const existing = await getEscrowByBookingId(input.bookingId);
        if (existing) return existing;
        const escrow = await createEscrow({
          ...input,
          buyerId: ctx.user.id,
          status: "pending",
        });
        return escrow;
      }),

    getByBooking: protectedProcedure
      .input(z.object({ bookingId: z.number() }))
      .query(async ({ input }) => getEscrowByBookingId(input.bookingId)),

    myEscrows: protectedProcedure.query(async ({ ctx }) => getUserEscrows(ctx.user.id)),

    confirmDelivery: protectedProcedure
      .input(z.object({ escrowId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const escrow = await getEscrowById(input.escrowId);
        if (!escrow) throw new TRPCError({ code: "NOT_FOUND" });
        if (escrow.buyerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateEscrow(input.escrowId, { status: "released", releasedAt: new Date() });
        await createNotification({
          userId: escrow.sellerId,
          type: "escrow_released",
          title: "Escrow Funds Released",
          message: "The buyer has confirmed delivery. Funds are being released.",
        });
        return { success: true };
      }),

    openDispute: protectedProcedure
      .input(z.object({ escrowId: z.number(), reason: z.string().min(10) }))
      .mutation(async ({ ctx, input }) => {
        const escrow = await getEscrowById(input.escrowId);
        if (!escrow) throw new TRPCError({ code: "NOT_FOUND" });
        if (escrow.buyerId !== ctx.user.id && escrow.sellerId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updateEscrow(input.escrowId, {
          status: "disputed",
          disputeReason: input.reason,
          disputeOpenedAt: new Date(),
        });
        return { success: true };
      }),

    updateStripeIntent: protectedProcedure
      .input(z.object({ escrowId: z.number(), paymentIntentId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const escrow = await getEscrowById(input.escrowId);
        if (!escrow) throw new TRPCError({ code: "NOT_FOUND" });
        if (escrow.buyerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
        await updateEscrow(input.escrowId, {
          stripePaymentIntentId: input.paymentIntentId,
          status: "funded",
          fundedAt: new Date(),
        });
        return { success: true };
      }),
  }),

  // ── Verification ──────────────────────────────────────────────────────────
  verification: router({
    submit: protectedProcedure
      .input(z.object({
        documentType: z.enum(["nin", "bvn", "passport", "drivers_license", "utility_bill"]),
        documentBase64: z.string(),
        documentMime: z.string(),
        selfieBase64: z.string().optional(),
        selfieMime: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const docBuffer = Buffer.from(input.documentBase64, "base64");
        const docKey = `verifications/${ctx.user.id}/doc-${Date.now()}`;
        const { url: documentUrl } = await storagePut(docKey, docBuffer, input.documentMime);

        let selfieUrl: string | undefined;
        if (input.selfieBase64 && input.selfieMime) {
          const selfieBuffer = Buffer.from(input.selfieBase64, "base64");
          const selfieKey = `verifications/${ctx.user.id}/selfie-${Date.now()}`;
          const { url } = await storagePut(selfieKey, selfieBuffer, input.selfieMime);
          selfieUrl = url;
        }

        await createVerification({
          userId: ctx.user.id,
          documentType: input.documentType,
          documentUrl,
          selfieUrl,
          status: "pending",
        });
        return { success: true };
      }),

    myStatus: protectedProcedure.query(async ({ ctx }) => getUserVerification(ctx.user.id)),
  }),

  // ── Notifications ─────────────────────────────────────────────────────────
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => getUserNotifications(ctx.user.id)),
    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await markNotificationRead(input.id);
        return { success: true };
      }),
    markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
      await markAllNotificationsRead(ctx.user.id);
      return { success: true };
    }),
  }),

  // ── Chatbot ───────────────────────────────────────────────────────────────
  chatbot: router({
    chat: publicProcedure
      .input(z.object({
        message: z.string().min(1),
        sessionKey: z.string(),
        listingId: z.number().optional(),
        listingContext: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const session = await getChatbotSession(input.sessionKey);
        const history: Array<{ role: string; content: string }> = session?.history
          ? JSON.parse(session.history)
          : [];

        const systemPrompt = `You are Homvera AI, an expert real estate and property services assistant for the Homvera NG marketplace platform in Nigeria.

Your capabilities:
1. LISTING Q&A: Answer questions about specific property listings, features, pricing, location, and availability.
2. PROPERTY SUGGESTIONS: Suggest properties based on user preferences (budget, location, type, bedrooms, etc.).
3. ESCROW GUIDANCE: Explain the escrow payment process step by step — initiation, funding, delivery confirmation, dispute handling.
4. VERIFICATION GUIDANCE: Guide users through the identity verification process (NIN, BVN, passport, etc.).

${input.listingContext ? `Current listing context:\n${input.listingContext}` : ""}

Always be helpful, professional, and concise. Format responses clearly. If asked about pricing, mention that prices are in Naira (₦) unless otherwise stated. Encourage users to verify agents and use escrow for secure transactions.`;

        const messages = [
          { role: "system" as const, content: systemPrompt },
          ...history.map(h => ({ role: h.role as "user" | "assistant", content: h.content })),
          { role: "user" as const, content: input.message },
        ];

        const response = await invokeLLM({ messages: messages as any });
        const rawContent = response.choices[0]?.message?.content;
        const reply = typeof rawContent === "string" ? rawContent : "I'm sorry, I couldn't process that. Please try again.";

        const updatedHistory = [
          ...history,
          { role: "user", content: input.message },
          { role: "assistant", content: reply },
        ].slice(-20); // Keep last 20 messages

        await upsertChatbotSession(input.sessionKey, updatedHistory, ctx.user?.id);
        return { reply };
      }),
  }),

  // ── Admin ─────────────────────────────────────────────────────────────────
  admin: router({
    stats: adminProcedure.query(async () => getAdminStats()),

    users: adminProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => getAllUsers(input.limit, input.offset)),

    updateUserRole: adminProcedure
      .input(z.object({ userId: z.number(), role: z.enum(["user", "admin"]), userRole: z.enum(["buyer", "seller", "agent", "admin"]).optional() }))
      .mutation(async ({ input }) => {
        await updateUserProfile(input.userId, { role: input.role, userRole: input.userRole });
        return { success: true };
      }),

    listings: adminProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => getAllListingsAdmin(input.limit, input.offset)),

    moderateListing: adminProcedure
      .input(z.object({ id: z.number(), status: z.enum(["active", "rejected", "pending"]), isFeatured: z.boolean().optional() }))
      .mutation(async ({ input }) => {
        await updateListing(input.id, { status: input.status, isFeatured: input.isFeatured });
        return { success: true };
      }),

    escrows: adminProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => getAllEscrowsAdmin(input.limit, input.offset)),

    resolveDispute: adminProcedure
      .input(z.object({ escrowId: z.number(), resolution: z.enum(["released", "refunded"]), notes: z.string().optional() }))
      .mutation(async ({ input }) => {
        await updateEscrow(input.escrowId, {
          status: input.resolution,
          resolvedAt: new Date(),
          notes: input.notes,
        });
        return { success: true };
      }),

    verifications: adminProcedure.query(async () => getPendingVerifications()),

    reviewVerification: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["approved", "rejected"]),
        adminNotes: z.string().optional(),
        userId: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateVerification(input.id, {
          status: input.status,
          adminNotes: input.adminNotes,
          reviewedBy: ctx.user.id,
          reviewedAt: new Date(),
        });
        if (input.status === "approved") {
          await updateUserProfile(input.userId, { isVerified: true });
        }
        await createNotification({
          userId: input.userId,
          type: "verification_update",
          title: input.status === "approved" ? "Identity Verified!" : "Verification Rejected",
          message: input.status === "approved"
            ? "Your identity has been verified. You now have a verified badge."
            : `Your verification was rejected. ${input.adminNotes ?? "Please resubmit with clearer documents."}`,
        });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
