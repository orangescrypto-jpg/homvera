import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

// ─── Mock DB ──────────────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  upsertUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  getUserById: vi.fn(),
  updateUserProfile: vi.fn(),
  getAllUsers: vi.fn(() => []),
  createListing: vi.fn(),
  getListingById: vi.fn(),
  getListingWithOwner: vi.fn(),
  searchListings: vi.fn(() => []),
  getFeaturedListings: vi.fn(() => []),
  getUserListings: vi.fn(() => []),
  updateListing: vi.fn(),
  deleteListing: vi.fn(),
  incrementListingViews: vi.fn(),
  getAllListingsAdmin: vi.fn(() => []),
  saveListing: vi.fn(),
  unsaveListing: vi.fn(),
  getUserSavedListings: vi.fn(() => []),
  isListingSaved: vi.fn(() => false),
  createBooking: vi.fn(),
  getBookingById: vi.fn(),
  getUserBookings: vi.fn(() => []),
  updateBookingStatus: vi.fn(),
  getOrCreateConversation: vi.fn(() => ({ id: 1, participant1Id: 1, participant2Id: 2, lastMessageAt: new Date(), createdAt: new Date() })),
  getUserConversations: vi.fn(() => []),
  getConversationMessages: vi.fn(() => []),
  sendMessage: vi.fn(),
  markMessagesRead: vi.fn(),
  createEscrow: vi.fn(() => ({ id: 1, bookingId: 1, buyerId: 1, sellerId: 2, amount: "1000", currency: "USD", status: "pending", createdAt: new Date(), updatedAt: new Date() })),
  getEscrowById: vi.fn(),
  getEscrowByBookingId: vi.fn(() => null),
  updateEscrow: vi.fn(),
  getUserEscrows: vi.fn(() => []),
  getAllEscrowsAdmin: vi.fn(() => []),
  createVerification: vi.fn(),
  getUserVerification: vi.fn(() => null),
  updateVerification: vi.fn(),
  getPendingVerifications: vi.fn(() => []),
  createNotification: vi.fn(),
  getUserNotifications: vi.fn(() => []),
  markNotificationRead: vi.fn(),
  markAllNotificationsRead: vi.fn(),
  getListingReviews: vi.fn(() => []),
  createReview: vi.fn(),
  getChatbotSession: vi.fn(() => null),
  upsertChatbotSession: vi.fn(),
  getAdminStats: vi.fn(() => ({ users: 10, listings: 25, escrows: 5, pendingVerifications: 2 })),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn(() => ({ key: "test-key", url: "/manus-storage/test-key" })),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(() => ({
    choices: [{ message: { content: "Hello! I can help you find a property." } }],
  })),
}));

// ─── Context Helpers ──────────────────────────────────────────────────────────
type AuthUser = NonNullable<TrpcContext["user"]>;

function makeUser(overrides?: Partial<AuthUser>): AuthUser {
  return {
    id: 1,
    openId: "test-open-id",
    email: "test@homvera.ng",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    userRole: "buyer",
    phone: null,
    avatarUrl: null,
    bio: null,
    location: null,
    isVerified: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
}

function makeAdminUser(): AuthUser {
  return makeUser({ role: "admin", userRole: "admin" });
}

function makeCtx(user?: AuthUser): TrpcContext {
  const clearedCookies: unknown[] = [];
  return {
    user: user ?? null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (_name: string, _opts: unknown) => { clearedCookies.push({ _name, _opts }); },
    } as TrpcContext["res"],
  };
}

// ─── Auth Tests ───────────────────────────────────────────────────────────────
describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user for authenticated users", async () => {
    const user = makeUser();
    const caller = appRouter.createCaller(makeCtx(user));
    const result = await caller.auth.me();
    expect(result).toMatchObject({ id: 1, email: "test@homvera.ng" });
  });
});

describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const clearedCookies: { name: string; options: Record<string, unknown> }[] = [];
    const ctx: TrpcContext = {
      user: makeUser(),
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {
        clearCookie: (name: string, options: Record<string, unknown>) => {
          clearedCookies.push({ name, options });
        },
      } as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: -1 });
  });
});

describe("auth.updateProfile", () => {
  it("updates profile for authenticated user", async () => {
    const { updateUserProfile } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.auth.updateProfile({ name: "Updated Name", phone: "+2348012345678" });
    expect(result).toEqual({ success: true });
    expect(updateUserProfile).toHaveBeenCalledWith(1, expect.objectContaining({ name: "Updated Name" }));
  });

  it("throws UNAUTHORIZED for unauthenticated users", async () => {
    const caller = appRouter.createCaller(makeCtx());
    await expect(caller.auth.updateProfile({ name: "Test" })).rejects.toThrow();
  });
});

// ─── Listings Tests ───────────────────────────────────────────────────────────
describe("listings.search", () => {
  it("returns listings array", async () => {
    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.listings.search({ limit: 10, offset: 0 });
    expect(Array.isArray(result)).toBe(true);
  });

  it("accepts category filter", async () => {
    const { searchListings } = await import("./db");
    const caller = appRouter.createCaller(makeCtx());
    await caller.listings.search({ category: "housing", limit: 10, offset: 0 });
    expect(searchListings).toHaveBeenCalledWith(expect.objectContaining({ category: "housing" }));
  });
});

describe("listings.featured", () => {
  it("returns featured listings", async () => {
    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.listings.featured();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("listings.create", () => {
  it("creates listing for authenticated user", async () => {
    const { createListing } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.listings.create({
      title: "Test Apartment in Lagos",
      category: "housing",
      propertyType: "apartment",
      price: "500000",
      priceUnit: "per_month",
    });
    expect(result).toEqual({ success: true });
    expect(createListing).toHaveBeenCalledWith(expect.objectContaining({
      title: "Test Apartment in Lagos",
      ownerId: 1,
      status: "pending",
    }));
  });

  it("throws UNAUTHORIZED for unauthenticated users", async () => {
    const caller = appRouter.createCaller(makeCtx());
    await expect(caller.listings.create({
      title: "Test", category: "housing", propertyType: "apartment", price: "100",
    })).rejects.toThrow();
  });
});

describe("listings.save / unsave", () => {
  it("saves a listing for authenticated user", async () => {
    const { saveListing } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.listings.save({ listingId: 5 });
    expect(result).toEqual({ success: true });
    expect(saveListing).toHaveBeenCalledWith(1, 5);
  });

  it("unsaves a listing for authenticated user", async () => {
    const { unsaveListing } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.listings.unsave({ listingId: 5 });
    expect(result).toEqual({ success: true });
    expect(unsaveListing).toHaveBeenCalledWith(1, 5);
  });
});

// ─── Bookings Tests ───────────────────────────────────────────────────────────
describe("bookings.create", () => {
  it("creates a booking for authenticated user", async () => {
    const { createBooking } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.bookings.create({ listingId: 1, sellerId: 2, message: "I'm interested" });
    expect(result).toEqual({ success: true });
    expect(createBooking).toHaveBeenCalledWith(expect.objectContaining({ buyerId: 1, sellerId: 2 }));
  });
});

// ─── Escrow Tests ─────────────────────────────────────────────────────────────
describe("escrow.initiate", () => {
  it("initiates escrow for authenticated buyer", async () => {
    const { createEscrow } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.escrow.initiate({ bookingId: 1, sellerId: 2, amount: "500000", currency: "USD" });
    expect(result).toBeDefined();
    expect(createEscrow).toHaveBeenCalled();
  });

  it("returns existing escrow if already initiated", async () => {
    const { getEscrowByBookingId } = await import("./db");
    vi.mocked(getEscrowByBookingId).mockResolvedValueOnce({
      id: 1, bookingId: 1, buyerId: 1, sellerId: 2, amount: "500000", currency: "USD",
      status: "pending", stripePaymentIntentId: null, stripeTransferId: null,
      fundedAt: null, releasedAt: null, disputeReason: null, disputeOpenedAt: null,
      resolvedAt: null, notes: null, createdAt: new Date(), updatedAt: new Date(),
    });
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.escrow.initiate({ bookingId: 1, sellerId: 2, amount: "500000" });
    expect(result?.id).toBe(1);
  });
});

// ─── Notifications Tests ──────────────────────────────────────────────────────
describe("notifications.list", () => {
  it("returns notifications for authenticated user", async () => {
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.notifications.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("notifications.markAllRead", () => {
  it("marks all notifications as read", async () => {
    const { markAllNotificationsRead } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    const result = await caller.notifications.markAllRead();
    expect(result).toEqual({ success: true });
    expect(markAllNotificationsRead).toHaveBeenCalledWith(1);
  });
});

// ─── Chatbot Tests ────────────────────────────────────────────────────────────
describe("chatbot.chat", () => {
  it("returns AI reply for a message", async () => {
    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.chatbot.chat({
      message: "Find me a 3-bedroom apartment in Lagos",
      sessionKey: "test-session-key",
    });
    expect(result).toHaveProperty("reply");
    expect(typeof result.reply).toBe("string");
    expect(result.reply.length).toBeGreaterThan(0);
  });

  it("handles listing context in chatbot", async () => {
    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.chatbot.chat({
      message: "What are the key features of this property?",
      sessionKey: "test-session-key-2",
      listingId: 1,
      listingContext: "3-bedroom apartment in Lekki Phase 1, Lagos. Price: ₦2,500,000/month",
    });
    expect(result.reply).toBeTruthy();
  });
});

// ─── Admin Tests ──────────────────────────────────────────────────────────────
describe("admin.stats", () => {
  it("returns platform stats for admin users", async () => {
    const caller = appRouter.createCaller(makeCtx(makeAdminUser()));
    const result = await caller.admin.stats();
    expect(result).toMatchObject({ users: 10, listings: 25, escrows: 5, pendingVerifications: 2 });
  });

  it("throws FORBIDDEN for non-admin users", async () => {
    const caller = appRouter.createCaller(makeCtx(makeUser()));
    await expect(caller.admin.stats()).rejects.toThrow();
  });
});

describe("admin.moderateListing", () => {
  it("approves a listing for admin", async () => {
    const { updateListing } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeAdminUser()));
    const result = await caller.admin.moderateListing({ id: 1, status: "active" });
    expect(result).toEqual({ success: true });
    expect(updateListing).toHaveBeenCalledWith(1, expect.objectContaining({ status: "active" }));
  });
});

describe("admin.reviewVerification", () => {
  it("approves verification and marks user as verified", async () => {
    const { updateVerification, updateUserProfile } = await import("./db");
    const caller = appRouter.createCaller(makeCtx(makeAdminUser()));
    const result = await caller.admin.reviewVerification({ id: 1, status: "approved", userId: 5 });
    expect(result).toEqual({ success: true });
    expect(updateVerification).toHaveBeenCalledWith(1, expect.objectContaining({ status: "approved" }));
    expect(updateUserProfile).toHaveBeenCalledWith(5, { isVerified: true });
  });
});
